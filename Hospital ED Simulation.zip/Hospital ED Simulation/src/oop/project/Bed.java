package oop.project;
public class Bed {
    private int id;
    private boolean occupied;
    private Arrival arrival;   // Composition: Arrival object
    private Triage triage;     // Composition: Triage object
    private Patient releaseTime; // Composition: Patient object to determine discharge/release time
    private String bedType;

    // Constructor
    public Bed(int id, String bedType) {
        this.id = id;
        this.bedType = bedType;
        this.occupied = false;
        this.arrival = null;       // Default: No Arrival data
        this.triage = null;        // Default: No Triage data
        this.releaseTime = null;   // Default: No Patient assigned for release time
    }

    // Admit a patient with all required details
    public void admitPatient(Arrival arrival, Triage triage, Patient patient) {
        this.occupied = true;
        this.arrival = arrival;         // Assign Arrival data
        this.triage = triage;           // Assign Triage data
        this.releaseTime = patient;     // Assign the Patient (used for release time)
    }

    // Mark the bed as occupied (without setting additional details)
    public void admitPatient() {
        this.occupied = true;
    }

    // Discharge the patient from the bed
    public void dischargePatient() {
        this.occupied = false;
        this.arrival = null;       // Clear Arrival data
        this.triage = null;        // Clear Triage data
        this.releaseTime = null;   // Clear Patient data
    }

    // Calculate the time spent in the bed (from Arrival to Discharge)
    public String calculateBedTime() {
        if (arrival == null || releaseTime == null) {
            System.err.println("Error: Missing Arrival or Release Time in Bed.");
            return "N/A";
        }

        double arrivalTime = arrival.getx(); // Arrival time in milliseconds
        double dischargeTime = releaseTime.getDischargeTime(); // Discharge time in milliseconds

        // Convert to minutes since midnight
        int arrivalMinutes = (int) (arrivalTime / 60000);
        int dischargeMinutes = (int) (dischargeTime / 60000);

        // Handle rollover (next day)
        int totalMinutes = dischargeMinutes - arrivalMinutes;
        if (totalMinutes < 0) {
            totalMinutes += 1440; // Add 24 hours in minutes
        }

        int hours = totalMinutes / 60;
        int minutes = totalMinutes % 60;

        // Convert to 12-hour format and determine AM/PM
        String period = (hours >= 12) ? "PM" : "AM";
        hours = hours % 12;
        if (hours == 0) {
            hours = 12; // Handle midnight and noon
        }

        return String.format("%02d:%02d %s", hours, minutes, period);
    }

    // Static method to assign a bed based on triage level
    public static Bed assignBedByTriage(HospitalManagementSystem hospitalManagementSystem, int entryNumber, int triageLevel, Arrival arrival, Triage triage) {
        String bedType;
        triageLevel = triage.gett();
        // Determine bed type based on triage level
        if (triageLevel == 1) {
            bedType = "Resuscitation Bed";
        } else if (triageLevel == 2) {
            bedType = "Acute Bed";
        } else if (triageLevel == 3 || triageLevel == 4) {
            bedType = "Sub-Acute Bed";
        } else {
            bedType = "Minor Bed";
        }

        // Attempt to admit the patient
        Bed bed = hospitalManagementSystem.admitPatientWithBed(entryNumber, bedType, arrival, triage, null);
        if (bed != null) {
            bed.bedType = bedType;
            bed.admitPatient(arrival, triage, null); // No patient initially for releaseTime
        } else {
            System.out.println("No bed available for triage level " + triageLevel + " patient.");
        }
        return bed;
    }

    // Static utility to check if all beds are occupied
    public static int checkAllBedsOccupied(HospitalManagementSystem hospitalManagementSystem, int triageLevel) {
        if (hospitalManagementSystem.getTotalAvailableBeds() == 0) {
            switch (triageLevel) {
                case 1:
                    return 0;
                case 2:
                    return 10;
                case 3:
                    return 30;
                case 4:
                    return 60;
                case 5:
                    return 120;
                default:
                    return 0;
            }
        }
        return -1; // Return -1 if not all beds are occupied
    }
    public static String determineBedType(int triageLevel) {
        if (triageLevel == 1) {
            return "Resuscitation Bed";
        } else if (triageLevel == 2) {
            return "Acute Bed";
        } else if (triageLevel == 3 || triageLevel == 4) {
            return "Sub-Acute Bed";
        } else {
            return "Minor Bed";
        }
    }

    @Override
    public String toString() {
        return "Bed ID: " + id +
               ", Type: " + bedType +
               ", Occupied: " + occupied +
               ", Arrival: " + (arrival != null ? arrival.getx() : "N/A") +
               ", Triage Level: " + (triage != null ? triage.gett() : "N/A");
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public String getBedType() {
        return bedType;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public Arrival getArrival() {
        return arrival;
    }

    public Triage getTriage() {
        return triage;
    }

    public Patient getReleaseTime() {
        return releaseTime;
    }

    public void setId(int id) {
        this.id = id;
    }
}
