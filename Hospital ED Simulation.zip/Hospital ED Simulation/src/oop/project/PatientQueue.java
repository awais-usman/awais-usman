package oop.project;

import java.util.*;

public class PatientQueue {
    private Queue<Patient> waitingPatients; // Queue to hold patients waiting for beds

    public PatientQueue() {
        waitingPatients = new LinkedList<>();
    }

    // Method to add a patient to the queue
    public void addPatient(Patient patient) {
        waitingPatients.add(patient);
    }

    // Method to rearrange patients based on their triage levels
    public List<Patient> rearrangePatients() {
        List<Patient> sortedPatients = new ArrayList<>(waitingPatients);
        // Sort patients based on their triage level
        sortedPatients.sort(Comparator.comparingInt(p -> p.getTriage().gett()));
        waitingPatients.clear(); // Clear the queue after sorting
        waitingPatients.addAll(sortedPatients); // Add sorted patients back to the queue
        return sortedPatients; // Return the sorted list
    }

    // Method to get the next patient from the queue
    public Patient getNextPatient() {
        return waitingPatients.poll(); // Remove and return the head of the queue
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return waitingPatients.isEmpty();
    }

    // Method to get the number of patients in the queue
    public int size() {
        return waitingPatients.size();
    }
}