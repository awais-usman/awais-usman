package oop.project;

import java.io.*;
import java.util.*;

public class HospitalManagementSystem {
    private final List<Bed> allBeds = new ArrayList<>(); // All beds, including unassigned ones

    public void loadBedsFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String bedType = parts[0].trim();
                int numberOfBeds = Integer.parseInt(parts[1].trim());

                for (int i = 0; i < numberOfBeds; i++) {
                    Bed bed = new Bed(allBeds.size() + 1, bedType);
                    allBeds.add(bed);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading beds from file: " + e.getMessage());
        }
    }

    public Bed admitPatientWithBed(int entryNumber, String bedType, Arrival arrival, Triage triage, Patient patient) {
        for (Bed bed : allBeds) {
            if (bed.getBedType().equals(bedType) && !bed.isOccupied()) {
                bed.setId(entryNumber);
                bed.admitPatient(arrival, triage, patient); // Assign arrival and triage data
                return bed;
            }
        }
        return null; // No available bed
    }


    public int getTotalAvailableBeds() {
        return (int) allBeds.stream().filter(bed -> !bed.isOccupied()).count();
    }

    public double calculateOverallBedUtilization() {
        long totalOccupiedBeds = allBeds.stream().filter(Bed::isOccupied).count();
        return allBeds.size() > 0 ? ((double) totalOccupiedBeds / allBeds.size()) * 100 : 0;
    }

    public double getUtilizationForBedType(String bedType) {
        long totalBeds = allBeds.stream().filter(bed -> bed.getBedType().equals(bedType)).count();
        long occupiedBeds = allBeds.stream()
                .filter(bed -> bed.getBedType().equals(bedType) && bed.isOccupied())
                .count();
        return totalBeds > 0 ? ((double) occupiedBeds / totalBeds) * 100 : 0;
    }

    public Bed getBedByEntryNumber(int entryNumber) {
        return allBeds.stream()
                .filter(bed -> bed.isOccupied() && bed.getId() == entryNumber)
                .findFirst()
                .orElse(null);
    }
}
