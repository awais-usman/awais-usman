package oop.project;


import java.util.*;
import java.io.BufferedWriter;
import java.io.IOException;

public class Patient {

    protected int entry;
    protected Arrival arr;
    protected Triage tr;
    protected double treatment;
    protected double discharge;
    protected boolean admission;
    protected double pddt;
    public double dischargeTime;
    protected Random r = new Random();
    private static int entryCounter =0;
    Scanner scanner = new Scanner(System.in);
    public int getEntryNumber() {
        return entry;
    }

    // Constructor to initialize the Patient object
    public Patient(Arrival a, Triage t) {
        arr = a;
        tr = t;
    }

    // Method to generate patient entry number
    public int seten() {
        this.entry= ++entryCounter;
        return entry;
    }

    // Setters and getters
    public void setAdmission(boolean t) {
        this.admission = t;
    }
    public int getDischargeTime() {
        return (int)dischargeTime;
    }

    // Setter for dischargeTime (if needed)
    public void setDischargeTime(double dischargeTime) {
        this.dischargeTime = dischargeTime;
    }

    public int getn() {
        return entry;
    }

    public Triage getTriage() {
        return tr;
    }

    public Arrival getArrival() {
        return arr;
    }

    public boolean getAdmission() {
        return admission;
    }

    // Method to calculate the treatment
    public void calculateTreatment(Triage t, Arrival a) {
        int tri = t.gett();
        float p, q;
        double b;

        switch (tri) {
        case 4:
            p = 1.64f;
            q = 5.72f;
            b = 355;
            break;

        default:
                p = r.nextFloat() * 5 + 1; // Random float between 1 and 6
                q = r.nextFloat() * 7 + 1; // Random float between 1 and 8
                b = r.nextInt(450) + 50; // Random integer between 50 and 500
                break;
        }

        if (a.getx() / b > 1000) {
            b = a.getx() / 1000; // Normalize b to prevent overflow
        }

        if (p <= 0 || b <= 0) {
            p = 1.5f;
            b = 100;
        }

        // Beta function adjustment
        double beta = Math.exp(
            Math.log(Math.PI) +
            Math.log(Math.pow(p - 1, p - 1)) +
            Math.log(Math.pow(q - 1, q - 1))
        );

        double rawtreatment = (Math.pow(a.getx() / b, p - 1) / b) *
                    Math.pow(1 + (a.getx() / b), -(p + q)) *
                    beta;
        
        treatment =  rawtreatment+ r.nextDouble() * 180;
        // Ensure treatment is within bounds
        treatment = Math.max(60, Math.min(240, treatment));

       
  
    }


    // Beta function for treatment calculation
    public float beta(float p, float q) {
        if (p <= 0 || q <= 0) {
            return 1;
        }
        return gamma(p) * gamma(q) / gamma(p + q);
    }

    // Gamma function
    public float gamma(float x) {
        if (x <= 0) {
            return 1;
        }

        if (x == 1 || x == 2) {
            return 1;
        }
        return (float) (Math.sqrt(2 * Math.PI * x) * Math.pow(x / Math.E, x));
    }

    // Method to write patient data to file
    public void writeToFile(BufferedWriter writer) throws IOException, InterruptedException {
    
        writer.write("==========================================\n");
        writer.write("Entry number of the patient: " + entry + "\n");
        writer.write("Arrival of the patient: " + arr.gett() + "\n");
        writer.write("Priority number of the patient: " + tr.gett() + "\n");
        writer.write("Treatment time of the patient: " + treatment + "\n");
        writer.write("Discharge time of the patient: " + discharge + "\n");
        writer.write("Post-discharge time: " + pddt + "\n");
        writer.write("==========================================\n");
    }

	   
    public double pdd(Arrival arrival) {
        double arrivalTime = arrival.getx();
        double w = 156; // Customizable constant
        double pddt = (1.0 / w) * Math.exp(-arrivalTime / w) * 1000; // Adjust to minutes

        // Constrain pddt to reasonable limits
        return Math.max(1, Math.min(pddt, 200)); // Between 1 and 200
    }


    public void calculateDischarge(Triage t, boolean c, Arrival a, HospitalManagementSystem hospitalManagementSystem) {
        int triageLevel = t.gett();
        int additionalDischargeTime = Bed.checkAllBedsOccupied(hospitalManagementSystem, triageLevel);

        calculateTreatment(t, a);

        int bufferTime = r.nextInt(100) + 50; // Random buffer time
        pddt = pdd(a); // Calculate pddt explicitly

        discharge = treatment + bufferTime + additionalDischargeTime + (c ? pddt : 0);

        // Constrain discharge time
        discharge = Math.max(1, Math.min(discharge, 1000)); // Between 1 and 1000
    }


}