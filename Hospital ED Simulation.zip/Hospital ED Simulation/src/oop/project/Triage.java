package oop.project;


import java.util.*;
import java.io.BufferedWriter;
import java.io.IOException;


public class Triage {
    private Arrival arr; // Arrival object
    private int triage; // Level
    private Random r; // Random instance
    private double cp; // Probability value
    private int disease; // Disease type

    
    public Triage(Arrival a, BufferedWriter writer) {
        arr = a; // Initialize Arrival
        r = new Random();
        cp = cp(a, writer); // Compute probability and log to file
        disease = r.nextInt(22) + 1; // Random disease from 1 to 24
        triage = tc(writer); // Compute triage level and log to file
    }

    public double cp(Arrival a, BufferedWriter writer) { //cumulative probability
        double mt = 150 + r.nextDouble() * 150; 
        double o = a.getx();
        double y = Math.min(o/mt, 1.0) * 100;
        if(y==100) {
        	y=r.nextDouble()*(90-70);   }
        double i = 5+(y/100)*(90-5);
   
        // Log to file
        try {
            writer.write("The probability value = " + i + "\n");

        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
        return i;}
    
    public String getn() {
            switch (disease) {
                case 1: return "ENT/Oral";
                case 2: return "Environmental/Temperature/MISC";
                case 3: return "Gastrointestinal";
                case 4: return "General Physician";
                case 5: return "Injury";
                case 6: return "Neurological";
                case 7: return "Eye";
                case 8: return "Nonemergent";
                case 9: return "Review";
                case 10: return "Paediatrics";
                case 11: return "Pain";
                case 12: return "Obstetrics/Gynaecology";
                case 13: return "Psychiatric/Behavioural";
                case 14: return "Regional Problems";
                case 15: return "Renal";
                case 16: return "Respiratory";
                case 17: return "Urinary/Reproductive";
                case 18: return "Cardiology";
                case 19: return "Dermatology";
                case 20: return "Trauma Surgery";
                default: return "General Physician";
            }
        }
   

    public int tc(BufferedWriter writer) {
        double[] div = new double[5];
        switch (disease) {
        case 1: 
            div = new double[]{5, 5, 10, 15, 65}; 
            break;

        case 2: 
            div = new double[]{10, 15, 20, 25, 30}; 
            break;

        case 3: 
            div = new double[]{10, 10, 15, 20, 45}; 
            break;

        case 4: 
            div = new double[]{5, 10, 15, 30, 40}; 
            break;

        case 5: 
            div = new double[]{15, 20, 20, 20, 25}; 
            break;

        case 6: 
            div = new double[]{5, 10, 10, 25, 50}; 
            break;

        case 7: 
            div = new double[]{8, 12, 15, 30, 35}; 
            break;

        case 8: 
            div = new double[]{10, 10, 15, 25, 40}; 
            break;

        case 9: 
            div = new double[]{1, 3, 5, 29, 62}; 
            break;

        case 10: 
            div = new double[]{10, 10, 20, 30, 30}; 
            break;

        case 11: 
            div = new double[]{2, 3, 10, 15, 70}; 
            break;

        case 12: 
            div = new double[]{5, 10, 15, 20, 50}; 
            break;

        case 13: 
            div = new double[]{5, 5, 10, 20, 60}; 
            break;

        case 14: 
            div = new double[]{10, 15, 20, 25, 30}; 
            break;

        case 15: 
            div = new double[]{5, 5, 10, 25, 55}; 
            break;

        case 16: 
            div = new double[]{5, 5, 10, 30, 50}; 
            break;

        case 17: 
            div = new double[]{10, 10, 15, 25, 40}; 
            break;

        case 18: 
            div = new double[]{10, 15, 20, 25, 30}; 
            break;

        case 19: 
            div = new double[]{8, 12, 15, 30, 35}; 
            break;

        case 20: 
            div = new double[]{5, 10, 15, 25, 45}; 
            break;

        case 21: 
            div = new double[]{5, 5, 10, 30, 50}; 
            break;

        case 22: 
            div = new double[]{5, 10, 15, 30, 40}; 
            break;

        default: 
            div = new double[]{20, 20, 20, 20, 20}; 
            break;
        }

        int triageLevel = ac(div, cp);

        // Log to file
        try {
            writer.write("\nTriage level: " + triageLevel + " for disease " + getn()+ "\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        return triageLevel;
    }

    public int ac(double[] div, double cp) {
        double c = 0, total = 0;
        for (double v : div) {
            total += v;
        }
        for (int i = 0; i < div.length; i++) {
            c += (div[i] / total) * 100;
            if (cp <= c) {
                return i + 1;
            }
        }
        return div.length;
    }

    public Arrival getArr() {
        return arr;
    }

    public int getd() {
        return disease;
    }

    public int gett() {
        return triage;
    }

    public void display(BufferedWriter writer) {
        try {
            writer.write(String.format("Probability = %.2f, Triage = %d, Disease = %d%n", cp, triage, disease));
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}