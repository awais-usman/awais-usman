package oop.project;

import java.util.Random;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.IOException;

public class Arrival {
    private float x;
    private Triage t;
    private Random r = new Random();
    private int tr;
    private String formattime;


    public void setx(Scanner s, BufferedWriter writer) {
  {
		
            try {
            	this.x=100+(float)(Math.random()*(400));
                if (x>1000) {x=1000;}
                if (x <= 0) {
                    throw new IllegalArgumentException("Number invalid");
                }
             
                int hours = (int) x;
                int minutes = (int) ((x - hours) * 60);
                
                String time = (hours >= 12) ? "PM" : "AM";
                hours = hours % 12;
                if (hours == 0) {
                    hours = 12;
                }
                
                formattime=String.format("%02d:%02d%s",hours,minutes,time);

                // Log to file
               
              
            } catch (IllegalArgumentException e) {
                try {
                    writer.write(e.getMessage() + "\n");
                } catch (IOException ioException) {
                    System.out.println("Error writing to file: " + ioException.getMessage());
                }
            }
        }
    }

    public Float getx() {
        return x;
    }
    
    public String gett() {
        return formattime;
    }
    

    public void sett(Triage ti) {
        t = ti;
        tr = t.gett();
    }

    public void prob(BufferedWriter writer) {

            double a = r.nextDouble(9) + 1;  // Random number between 1 and 10
            int b = r.nextInt(99) + 1;  // Random number between 1 and 100
            
            switch (tr) {
                case 4: {
                    double p = 0.914 / 180;
                    double o = 1 / Math.pow(x / 180, 0.086);
                    double i = p * o;
                    double u = Math.pow(x / 180, 0.914);
                    double j = i * 1 / Math.exp(u);
                    
                    // Log to file
                    try {
                        writer.write(String.format("\nThe interval arrival time="+j));
                        
                    } catch (IOException e) {
                        System.out.println("Error writing to file: " + e.getMessage());
                    }
                    break;
                }

                default: {
                    // Default logic (if needed)
                    double p = a / b;
                    double o = 1 / Math.pow(x / b, 0.086);
                    double i = p * o;
                    double u = Math.pow(x / b, a);
                    double j = i * 1 / Math.exp(u);
                    
                    // Log to file
                    try {
                        writer.write(String.format("\nThe interval arrival time="+j));
                    } catch (IOException e) {
                        System.out.println("Error writing to file: " + e.getMessage());
                    }
                    break;
                }
            }

    }
}