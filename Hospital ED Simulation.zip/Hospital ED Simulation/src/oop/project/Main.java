package oop.project;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String doctorFilePath = "doctors.txt";
        String bedFilePath = "input.txt";

        try (FileWriter fileWriter = new FileWriter("simulationresults.txt");
             BufferedWriter writer = new BufferedWriter(fileWriter)) {

            HospitalManagementSystem hospitalManagementSystem = new HospitalManagementSystem();
            hospitalManagementSystem.loadBedsFromFile(bedFilePath);

            Doctor[] doctors = Doctor.loadDoctorsFromFile(doctorFilePath);
            if (doctors.length == 0) {
                writer.write("No doctors loaded. Please check the file.\n");
                return;
            }

            int numPatients = 0;
            try (BufferedReader br = new BufferedReader(new FileReader("patientcount.txt"))) {
                numPatients = Integer.parseInt(br.readLine());
            } catch (IOException e) {
                writer.write("Error reading patient count. Using default of 100.\n");
                numPatients = 100;
            }

            writer.write("Total Available Beds: " + hospitalManagementSystem.getTotalAvailableBeds() + "\n");
            writer.write("\nStarting patient arrival simulation...\n");

            List<Patient> patients = new ArrayList<>();
            PatientQueue patientQueue = new PatientQueue();
            int sortedPatientsCount = 0;

            // Process patient arrivals
            for (int i = 1; i <= numPatients; i++) {
                writer.write("\n--- Patient " + i + " ---\n");

                Arrival arrival = new Arrival();
                arrival.setx(scanner, writer);

                Triage triage = new Triage(arrival, writer);
                triage.display(writer);

                Patient patient = new Patient(arrival, triage);
                int entryNumber = patient.seten();

                patient.calculateTreatment(triage, arrival);
                patient.calculateDischarge(triage, false, arrival, hospitalManagementSystem);
                patient.pdd(arrival);
                patient.writeToFile(writer);
                
                String department = Doctor.getDepartmentForDisease(triage);
                writer.write("Assigned Department: " + department + "\n");

                Doctor assignedDoctor = Doctor.assignDoctor(doctors, triage, department);
                if (assignedDoctor.getDoctorId() != 0) {
                    writer.write("Assigned Doctor:\n");
                    assignedDoctor.displayDoctorInfo(writer);
                    // Assign treatment
                    String treatment = Doctor.assignTreatment(triage);
                    writer.write(treatment + "\n");
                    
                    // Determine discharge stage
                    String discharge = Doctor.dischargeStage(triage.gett());
                    writer.write("Discharge Stage: " + discharge + "\n");
                } else {
                    writer.write("No doctor available for this patient.\n");
                }

                String bedType = Bed.determineBedType(triage.gett());
                Bed assignedBed = hospitalManagementSystem.admitPatientWithBed(
                    entryNumber,
                    bedType,
                    arrival,
                    triage,
                    patient
                );

                if (assignedBed != null) {
                    writer.write("Assigned Bed:\n");
                    writer.write(assignedBed.toString() + "\n");
                    writer.write("Bed Time for Patient: " + assignedBed.calculateBedTime() + "\n");
                } else {
                    patientQueue.addPatient(patient);
                    writer.write("No bed available for Patient " + i + ". Added to waiting queue.\n");
                }

                writer.write("Total Available Beds: " + hospitalManagementSystem.getTotalAvailableBeds() + "\n");
                writer.write("\n--- End of Patient " + i + " ---\n");
                patients.add(patient);
            }

            // Process waiting patients
            if (!patientQueue.isEmpty()) {
                writer.write("\nRearranging waiting patients based on triage levels...\n");
                List<Patient> sortedPatients = patientQueue.rearrangePatients();
                sortedPatientsCount = sortedPatients.size();

                for (Patient waitingPatient : sortedPatients) {
                    Arrival arrival = waitingPatient.getArrival();
                    Triage triage = waitingPatient.getTriage();

                    String bedType = Bed.determineBedType(triage.gett());
                    Bed assignedBed = hospitalManagementSystem.admitPatientWithBed(
                        waitingPatient.getEntryNumber(),
                        bedType,
                        arrival,
                        triage,
                        waitingPatient
                    );

                    if (assignedBed != null) {
                        writer.write("Assigned Bed to waiting Patient " + waitingPatient.getEntryNumber() + ".\n");
                        writer.write(assignedBed.toString() + "\n");
                        writer.write("Bed Time for Patient: " + assignedBed.calculateBedTime() + "\n");
                    } else {
                        writer.write("No bed available for waiting Patient " + waitingPatient.getEntryNumber() + ".\n");
                    }
                }
            }

            double traineeUtilization = Doctor.calculateTraineeDoctorUtilization(doctors);
            double overallBedUtilization = hospitalManagementSystem.calculateOverallBedUtilization();
            int patientsSeenPercent = ((numPatients - sortedPatientsCount) * 100) / numPatients;

            writer.write("\nFinal Metrics:\n");
            writer.write("Utilization of Trainee Doctors: " + traineeUtilization + "%\n");
            writer.write("Overall Bed Utilization: " + overallBedUtilization + "%\n");
            writer.write("Patients Seen in Recommended Time: " + patientsSeenPercent + "%\n");
            writer.write("Total Patients Who Had to Wait: " + sortedPatientsCount + "\n");

            writer.write("\nBed Type Utilization:\n");
            writer.write(String.format("Resuscitation Bed: %.2f%%\n", hospitalManagementSystem.getUtilizationForBedType("Resuscitation Bed")));
            writer.write(String.format("Acute Bed: %.2f%%\n", hospitalManagementSystem.getUtilizationForBedType("Acute Bed")));
            writer.write(String.format("Sub-Acute Bed: %.2f%%\n", hospitalManagementSystem.getUtilizationForBedType("Sub-Acute Bed")));
            writer.write(String.format("Minor Bed: %.2f%%\n", hospitalManagementSystem.getUtilizationForBedType("Minor Bed")));
            // Pass metrics to GUI
            SWTApplicationBuilder.launch(
                    "Hospital Utilization Metrics",
                    traineeUtilization,
                    overallBedUtilization,
                    patientsSeenPercent,
                    sortedPatientsCount,
                    hospitalManagementSystem.getUtilizationForBedType("Resuscitation Bed"),
                    hospitalManagementSystem.getUtilizationForBedType("Minor Bed"),
                    hospitalManagementSystem.getUtilizationForBedType("Sub-Acute Bed"),
                    hospitalManagementSystem.getUtilizationForBedType("Acute Bed"));

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
