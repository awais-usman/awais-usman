package oop.project;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*; // For Swing components

public class SWTApplicationBuilder {

    /**
     * @wbp.parser.entryPoint
     */
    public static void launch(String title, double traineeUtilization, double bedUtilization, int patientsSeenPercent,
                              int numPatientsWaiting, double resuscitationBedUtilization, double minorBedUtilization,
                              double subAcuteBedUtilization, double acuteBedUtilization) {
        // Create the SWT Display and Shell
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText(title);
        shell.setSize(1000, 600);
        shell.setLayout(new GridLayout(2, false)); // 2 columns: 1 for chart, 1 for text

        // Left column: Chart
        Composite chartComposite = new Composite(shell, SWT.EMBEDDED);
        chartComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        java.awt.Frame chartFrame = org.eclipse.swt.awt.SWT_AWT.new_Frame(chartComposite);
        DefaultCategoryDataset dataset = createDataset(
            traineeUtilization, 
            bedUtilization, 
            patientsSeenPercent, 
            resuscitationBedUtilization, 
            minorBedUtilization, 
            subAcuteBedUtilization, 
            acuteBedUtilization
        );
        JFreeChart chart = createChart(dataset, "Hospital Metrics");

        JPanel chartPanel = new ChartPanel(chart);
        chartFrame.add(chartPanel);

        // Right column: Text Information
        Composite textComposite = new Composite(shell, SWT.NONE);
        textComposite.setLayout(new GridLayout(1, false));
        textComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true));

        // Add Utilization Percentages
        Label utilizationLabel = new Label(textComposite, SWT.NONE);
        utilizationLabel.setText("Utilization Metrics:");

        Label traineeLabel = new Label(textComposite, SWT.NONE);
        traineeLabel.setText("Trainee Doctors: " + String.format("%.2f", traineeUtilization) + "%");

        Label bedLabel = new Label(textComposite, SWT.NONE);
        bedLabel.setText("Overall Bed Utilization: " + String.format("%.2f", bedUtilization) + "%");

        Label patientsSeenLabel = new Label(textComposite, SWT.NONE);
        patientsSeenLabel.setText("Patients Seen in Recommended Time: " + patientsSeenPercent + "%");

        Label waitingPatientsLabel = new Label(textComposite, SWT.NONE);
        waitingPatientsLabel.setText("Patients Who Had to Wait: " + numPatientsWaiting);

        // Add Bed Type Utilization
        Label bedTypeUtilizationLabel = new Label(textComposite, SWT.NONE);
        bedTypeUtilizationLabel.setText("Bed Type Utilization:");

        Label resuscitationLabel = new Label(textComposite, SWT.NONE);
        resuscitationLabel.setText("Resuscitation Beds: " + String.format("%.2f", resuscitationBedUtilization) + "%");

        Label minorLabel = new Label(textComposite, SWT.NONE);
        minorLabel.setText("Minor Beds: " + String.format("%.2f", minorBedUtilization) + "%");

        Label subAcuteLabel = new Label(textComposite, SWT.NONE);
        subAcuteLabel.setText("Sub-Acute Beds: " + String.format("%.2f", subAcuteBedUtilization) + "%");

        Label acuteLabel = new Label(textComposite, SWT.NONE);
        acuteLabel.setText("Acute Beds: " + String.format("%.2f", acuteBedUtilization) + "%");

        // Open the Shell and start the SWT event loop
        shell.open();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }

    private static DefaultCategoryDataset createDataset(double traineeUtilization, double bedUtilization, int patientsSeenPercent,
                                                        double resuscitationBedUtilization, double minorBedUtilization,
                                                        double subAcuteBedUtilization, double acuteBedUtilization) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Add general metrics
        dataset.addValue(traineeUtilization, "Utilization (%)", "Trainee Doctors");
        dataset.addValue(bedUtilization, "Utilization (%)", "Overall Beds");
        dataset.addValue(patientsSeenPercent, "Performance (%)", "Patients Seen in Time");

        // Add bed type utilizations
        dataset.addValue(resuscitationBedUtilization, "Utilization (%)", "Resuscitation Beds");
        dataset.addValue(minorBedUtilization, "Utilization (%)", "Minor Beds");
        dataset.addValue(subAcuteBedUtilization, "Utilization (%)", "Sub-Acute Beds");
        dataset.addValue(acuteBedUtilization, "Utilization (%)", "Acute Beds");

        return dataset;
    }

    /**
     * @wbp.parser.entryPoint
     */
    private static JFreeChart createChart(DefaultCategoryDataset dataset, String title) {
        return ChartFactory.createBarChart(
                title,                   // Chart title
                "Metrics",               // Domain axis label
                "Percentage",            // Range axis label
                dataset,                 // Data
                PlotOrientation.VERTICAL,// Orientation
                true,                    // Include legend
                true,                    // Tooltips
                false                    // URLs
        );
    }
}
