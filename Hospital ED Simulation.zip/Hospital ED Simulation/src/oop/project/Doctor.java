package oop.project;

import java.io.*;
import java.util.Random;

class Doctor {
    private int doctorId;
    private String name;
    private String department; // e.g., cardiology, gastroenterology, etc.
    private String category; // Intern, Junior Resident, Senior Resident, Registrar, Consultant
    private boolean isAvailable;
    private int maxPatients; // Max patients the doctor can handle simultaneously
    private int currentPatients; // Track current patients being handled by the doctor

    // Constructor
    public Doctor(int id, String n, String dept, String cat, int maxP) {
        doctorId = id;
        name = n;
        department = dept;
        category = cat;
        isAvailable = true;  // Initially, assume doctor is available
        maxPatients = maxP;
        currentPatients = 0; // Start with no patients
    }

    // Default Constructor
    public Doctor() {
        this(0, "null", "null", "null", 0);
    }

    // Getters and Setters
    public void setDoctorId(int id) {
        doctorId = id;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setName(String docName) {
        name = docName;
    }

    public String getName() {
        return name;
    }

    public void setDepartment(String dept) {
        department = dept;
    }

    public String getDepartment() {
        return department;
    }

    public void setCategory(String cat) {
        category = cat;
    }

    public String getCategory() {
        return category;
    }

    public void setAvailability(boolean status) {
        isAvailable = status;
    }

    public boolean getAvailability() {
        return isAvailable;
    }

    public void setMaxPatients(int maxP) {
        maxPatients = maxP;
    }

    public int getMaxPatients() {
        return maxPatients;
    }

    public int getCurrentPatients() {
        return currentPatients;
    }

    // Increase the current patients count
    public void increasePatients() {
        if (currentPatients < maxPatients) {
            currentPatients++;
            if (currentPatients >= maxPatients) {
                setAvailability(false);  // Mark doctor as unavailable if capacity is reached
            }
            else if (currentPatients < maxPatients) {
            	setAvailability(true);
            }
        }
    }

    // Decrease the current patients count
    public void decreasePatients() {
        if (currentPatients > 0) {
            currentPatients--;
            if (currentPatients < maxPatients) {
                setAvailability(true);  // Mark doctor as available again if capacity goes below max
            }
        }
    }

    public void displayDoctorInfo(BufferedWriter writer) throws IOException {
        String doctorInfo = "Doctor ID: " + doctorId + "\n" +
                            "Name: " + name + "\n" +
                            "Department: " + department + "\n" +
                            "Category: " + category + "\n" +
                            "Available: " + (isAvailable ? "Yes" : "No") + "\n" +
                            "Max Patients: " + maxPatients + "\n" +
                            "Current Patients: " + currentPatients + "\n";

        if (writer != null) {
            writer.write(doctorInfo);
            writer.flush(); // Ensure data is written to the output stream
        } else {
            System.out.print(doctorInfo); // Fallback to console output if writer is null
        }
    }

    // Method to map triage level to department
    public static String getDepartmentForDisease(Triage t) {
        switch (t.getd()) {
            case 1: return "ENT/Oral";
            case 2: return "Environmental/Temperature/MISC";
            case 3: return "Gastrointestinal";
            case 4: return "General Physician";
            case 5: return "Injury";
            case 6: return "Neurological";
            case 7: return "Eye";
            case 8: return "Nonemergent";
            case 9: return "Review";
            case 10: return "Paediatrics";
            case 11: return "Pain";
            case 12: return "Obstetrics/Gynaecology";
            case 13: return "Psychiatric/Behavioural";
            case 14: return "Regional Problems";
            case 15: return "Renal";
            case 16: return "Respiratory";
            case 17: return "Urinary/Reproductive";
            case 18: return "Cardiology";
            case 19: return "Dermatology";
            case 20: return "Trauma Surgery";
            default: return "General Physician";
        }
    }

    // Assign an available doctor based on triage level and department
    public static Doctor assignDoctor(Doctor[] doctors, Triage triagelevel, String department) {
        if (triagelevel.gett() <= 2) { 
            for (Doctor doctor : doctors) {
                if (doctor.getAvailability() 
                        && doctor.getDepartment().equals(department) 
                        && doctor.getCategory().equals("Consultant") 
                        && doctor.getCurrentPatients() < doctor.getMaxPatients()) {
                    doctor.increasePatients(); 
                    return doctor;
                }
            }
            }

         else {
            // For non-critical patients, select randomized doctors
            int eligibleDoctorCount = 0;
            for (Doctor doctor : doctors) {
                if (doctor.getAvailability() 
                        && doctor.getDepartment().equals(department) 
                        && (doctor.getCategory().equals("Intern") || doctor.getCategory().equals("Junior Resident") || doctor.getCategory().equals("Senior Resident"))
                        && doctor.getCurrentPatients() < doctor.getMaxPatients()) { // Check if doctor can handle more patients
                    eligibleDoctorCount++;
                }
            }

            if (eligibleDoctorCount > 0) {
                Random rand = new Random();
                int randomIndex = rand.nextInt(eligibleDoctorCount);
                int currentIndex = 0;

                for (Doctor doctor : doctors) {
                    if (doctor.getAvailability() 
                            && doctor.getDepartment().equals(department) 
                            && (doctor.getCategory().equals("Intern") || doctor.getCategory().equals("Junior Resident") || doctor.getCategory().equals("Senior Resident"))
                            && doctor.getCurrentPatients() < doctor.getMaxPatients()) { // Check if doctor can handle more patients
                        if (currentIndex == randomIndex) {
                            doctor.increasePatients(); // Increase patient count
                            return doctor;
                        }
                        currentIndex++;
                    }
                }
            }
        }
        return new Doctor(0, "None", "None", "None", 0); // If no doctor is available
    }
    public static String assignTreatment(Triage triage) {
        Random random = new Random();
        int triageLevel = triage.gett();
        StringBuilder treatmentPlan = new StringBuilder("Treatment Assigned: ");

        int numberOfTreatments = random.nextInt(2) + 1; // Randomly assign 1 or 2 treatments

        switch (triageLevel) {
            case 1:
            case 2:
                if (numberOfTreatments == 1) {
                    treatmentPlan.append(random.nextBoolean() ? "Treatment" : "Imaging");
                } else {
                    treatmentPlan.append("Treatment and Imaging");
                }
                break;

            case 3:
                if (numberOfTreatments == 1) {
                    treatmentPlan.append(random.nextBoolean() ? "Senior Physician Consult" : "Imaging");
                } else {
                    treatmentPlan.append("Senior Physician Consult and Imaging");
                }
                break;

            case 4:
                treatmentPlan.append("Senior Physician Consult");
                break;

            case 5:
                treatmentPlan.append(random.nextBoolean() ? "Skip" : "Nursing");
                break;

            default:
                treatmentPlan.append("No treatment required");
        }

        return treatmentPlan.toString();
    }

    // Discharge Stage: Decide where the patient goes after treatment
    public static String dischargeStage(int triageLevel) {
        Random random = new Random();
        switch (triageLevel) {
            case 1:
                return random.nextBoolean() ? "Transfer to Alternative Hospital" : "Inpatient Bed";
            case 2:
                return "Inpatient Bed";
            case 3:
                return "Observation Unit";
            case 4:
            case 5:
                return "Home";
            default:
                return "Hospital Morgue";
        }
    }

    public static double calculateTraineeDoctorUtilization(Doctor[] doctors) {
        int totalTraineeDoctors = 0; // Count of trainee doctors
        int totalPatientsHandled = 0; // Total patients handled by trainee doctors

        // Iterate through the list of doctors
        for (Doctor doctor : doctors) {
            // Check if the doctor is a trainee
            if (doctor.getCategory().equals("Intern") || 
                doctor.getCategory().equals("Junior Resident") || 
                doctor.getCategory().equals("Senior Resident")) {
                
                totalTraineeDoctors++; // Increment the count of trainee doctors
                totalPatientsHandled += doctor.getCurrentPatients(); // Add current patients to the total
            }
        }

        // Calculate utilization percentage
        // Utilization = (Total Patients Handled) / (Total Trainee Doctors * Max Patients per Doctor) * 100
        return totalTraineeDoctors > 0 ? 
               (double) totalPatientsHandled / (totalTraineeDoctors * doctors[0].getMaxPatients()) * 100 : 0;
    }
    // Load doctors from a file
    public static Doctor[] loadDoctorsFromFile(String filePath) {
        Doctor[] doctors = new Doctor[100]; // Assume a maximum of 100 doctors for simplicity
        int doctorCount = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(","); // Assuming CSV format
                int id = Integer.parseInt(data[0].trim());
                String name = data[1].trim();
                String department = data[2].trim();
                String category = data[3].trim();
                int maxPatients = Integer.parseInt(data[4].trim());

                doctors[doctorCount++] = new Doctor(id, name, department, category, maxPatients);
            }
        } catch (IOException e) { 
            System.err.println("Error reading doctor file: " + e.getMessage());
        }
        

        Doctor[] result = new Doctor[doctorCount];
        System.arraycopy(doctors, 0, result, 0, doctorCount);
        return result;
    }
}